<?php
require 'db.php';
$id = intval($_GET['id'] ?? 0);
if ($id <= 0) { echo "Invalid booking id"; exit; }
$db = getDB();
$stmt = $db->prepare('SELECT * FROM bookings WHERE id = ?');
$stmt->execute([$id]);
$booking = $stmt->fetch(PDO::FETCH_ASSOC);
if (!$booking) { echo "Booking not found"; exit; }
$prices = ['haircut'=>500,'coloring'=>1500,'styling'=>800,'facial'=>1200];
$amount = $prices[$booking['service']] ?? 500;
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>Pay for booking</title>
</head>
<body>
<h2>Pay for booking #<?php echo $booking['id'] ?></h2>
<p>Full name: <?php echo htmlspecialchars($booking['fullname']) ?></p>
<p>Service: <?php echo htmlspecialchars($booking['service']) ?></p>
<p>Date: <?php echo htmlspecialchars($booking['date']) ?> <?php echo htmlspecialchars($booking['time']) ?></p>
<p>Amount: Rs <?php echo $amount ?></p>
<form method="post" action="process_payment.php">
  <input type="hidden" name="booking_id" value="<?php echo $booking['id'] ?>">
  <input type="hidden" name="amount" value="<?php echo $amount ?>">
  <label>Payment method
    <select name="method">
      <option value="card">Card</option>
      <option value="cash">Cash</option>
      <option value="bank">Bank Transfer</option>
    </select>
  </label>
  <button type="submit">Pay Now</button>
</form>
</body>
</html>