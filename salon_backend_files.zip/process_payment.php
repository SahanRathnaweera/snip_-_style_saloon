<?php
require 'db.php';
if ($_SERVER['REQUEST_METHOD'] !== 'POST') { header('Location: booknow.html'); exit; }
$booking_id = intval($_POST['booking_id'] ?? 0);
$method = trim($_POST['method'] ?? '');
$amount = floatval($_POST['amount'] ?? 0);
if ($booking_id <= 0) { echo "Invalid"; exit; }
$db = getDB();
$stmt = $db->prepare('INSERT INTO payments (booking_id,method,amount,paid_at) VALUES (?,?,?,datetime("now"))');
$stmt->execute([$booking_id,$method,$amount]);
$stmt = $db->prepare('UPDATE bookings SET paid = 1 WHERE id = ?');
$stmt->execute([$booking_id]);
echo "Payment successful";
?>